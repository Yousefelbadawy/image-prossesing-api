var meassage = "hello world";
console.log(meassage);
